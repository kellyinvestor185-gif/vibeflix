import React from 'react';

function App() {
  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <h1>Welcome to VibeFlix 🎬</h1>
      <p>Your free movie streaming app is live!</p>
    </div>
  );
}

export default App;